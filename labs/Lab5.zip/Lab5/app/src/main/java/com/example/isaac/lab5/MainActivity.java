package com.example.isaac.lab5;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void notHappy(View view) {
        TextView notHappy = findViewById(R.id.textView);
        EditText name = findViewById(R.id.editText);
        String nameValue = name.getText().toString();
        notHappy.setText("I'm not happy, " + nameValue + ". Not happy!");
        ImageView boss = findViewById(R.id.imageView);
        boss.setImageResource(R.drawable.boss);
    }
}
