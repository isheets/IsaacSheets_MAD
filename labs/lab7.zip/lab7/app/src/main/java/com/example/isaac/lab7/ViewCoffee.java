package com.example.isaac.lab7;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ViewCoffee extends Activity {

    private String coffeeDrink;
    private String coffeeURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Intent intent = getIntent();

        coffeeDrink = intent.getStringExtra("coffee");
        coffeeURL = intent.getStringExtra("url");

        TextView coffeeOrder = findViewById(R.id.textView2);
        coffeeOrder.setText(coffeeDrink + " is your perfect coffee drink.");

        Button details = findViewById(R.id.button2);

        View.OnClickListener onclick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seeDetails(v);
            }
        };

        details.setOnClickListener(onclick);
    }

     private void seeDetails(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(coffeeURL));
        startActivity(intent);
     }


}
