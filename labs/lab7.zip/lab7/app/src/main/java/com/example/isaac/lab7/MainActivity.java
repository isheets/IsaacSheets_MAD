package com.example.isaac.lab7;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void getCoffee(View view) {
        String coffeeOrder = "";
        String coffeeURL = "";

        //start with decaf
        ToggleButton toggle = findViewById(R.id.toggleButton);
        if(!toggle.isChecked()) {
            coffeeOrder = "Decaf ";
        }

        Spinner milk = findViewById(R.id.spinner);
        String milkType = String.valueOf(milk.getSelectedItem());

        RadioGroup size = findViewById(R.id.radioGroup);
        int size_id = size.getCheckedRadioButtonId();

        CheckBox sweetBox = findViewById(R.id.checkBox);
        Boolean sweet = sweetBox.isChecked();



        if (size_id == -1) {
            //toast
            Context context = getApplicationContext();
            CharSequence text = "pick a size!";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else {
            if (size_id == R.id.radioButton) {
                if (sweet) {
                    //small sweet drink: cubano con panna
                    coffeeOrder += "Cafe Cubano";
                    coffeeURL = "https://en.wikipedia.org/wiki/Cuban_espresso";
                }
                else {
                    //small regular drink: espresso
                    coffeeOrder += "Double Espresso";
                    coffeeURL = "https://en.wikipedia.org/wiki/Espresso";
                }
            }
            if (size_id == R.id.radioButton2) {
                if (sweet) {
                    //med sweet drink: mochaccino
                    coffeeOrder += milkType;
                    coffeeOrder += " Mochaccino";
                    coffeeURL = "https://en.wiktionary.org/wiki/mochaccino";
                }
                else {
                    //med regular drink: 8 oz americano
                    coffeeOrder += "8oz Americano";
                    coffeeURL = "http://coffee.wikia.com/wiki/Americano";
                }
            }
            if (size_id == R.id.radioButton3) {
                if (sweet) {
                    //big sweet drink: mocha
                    coffeeOrder += milkType;
                    coffeeOrder += " Mocha";
                    coffeeURL = "https://en.wikipedia.org/wiki/Caff%C3%A8_mocha";
                }
                else {
                    //big regular drink: latte
                    coffeeOrder += milkType;
                    coffeeOrder += " Latte";
                    coffeeURL = "https://en.wikipedia.org/wiki/Latte";
                }
            }
        }

        Intent intent = new Intent(this, ViewCoffee.class);

        intent.putExtra("coffee", coffeeOrder);
        intent.putExtra("url", coffeeURL);

        startActivity(intent);
    }
}