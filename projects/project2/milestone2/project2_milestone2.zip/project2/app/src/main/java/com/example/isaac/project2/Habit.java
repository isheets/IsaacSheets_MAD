package com.example.isaac.project2;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Calendar;
import java.util.Date;



public class Habit implements Parcelable {

    String habitTitle;
    int numTimes;
    int timeInterval;
    float costPerTime;
    float costPerSec;
    Date dateCreated;
    String timeSince;
    double moneySaved;

    public Habit(String habitTitle, int numTimes, int timeInterval, float costPerTime, float costPerSec, Date dateCreated, String timeSince, double moneySaved) {
        this.habitTitle = habitTitle;
        this.numTimes = numTimes;
        this.timeInterval = timeInterval;

        this.costPerTime = costPerTime;
        this.costPerSec = costPerSec;
        this.dateCreated = dateCreated;
        this.timeSince = timeSince;
        this.moneySaved = moneySaved;
    }

    public Habit() {
        this.habitTitle = null;
        this.numTimes = 0;
        this.timeInterval = 0;
        this.costPerTime = 0;
        this.costPerSec = 0;
        this.dateCreated = null;
        this.timeSince = null;
        this.moneySaved = 0;
    }

    public String getHabitTitle() {
        return habitTitle;
    }

    public void setHabitTitle(String habitTitle) {
        this.habitTitle = habitTitle;
    }

    public int getNumTimes() {
        return numTimes;
    }

    public void setNumTimes(int numTimes) {
        this.numTimes = numTimes;
    }

    public int getTimeInterval() {
        return timeInterval;
    }

    public void setTimeInterval(int timeInterval) {
        this.timeInterval = timeInterval;
    }

    public float getCostPerTime() {
        return costPerTime;
    }

    public void setCostPerTime(float costPerTime) {
        this.costPerTime = costPerTime;
    }

    public float getCostPerSec() {
        return costPerSec;
    }

    public void setCostPerSec(float costPerSec) {
        this.costPerSec = costPerSec;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getTimeSince() {
        return timeSince;
    }

    public void setTimeSince(String timeSince) {
        this.timeSince = timeSince;
    }

    public double getMoneySaved() {
        return moneySaved;
    }

    public void setMoneySaved(double moneySaved) {
        this.moneySaved = moneySaved;
    }

    //parceable stuff

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public Habit createFromParcel(Parcel in) {
            return new Habit(in);
        }

        public Habit[] newArray(int size) {
            return new Habit[size];
        }
    };

    public Habit(Parcel in){
        this.habitTitle = in.readString();
        this.numTimes = in.readInt();
        this.timeInterval = in.readInt();

        this.costPerTime = in.readFloat();
        this.costPerSec = in.readFloat();
        this.dateCreated = new Date(in.readLong());
        this.timeSince = in.readString();
        this.moneySaved = in.readDouble();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.habitTitle);
        dest.writeInt(this.numTimes);
        dest.writeInt(this.timeInterval);
        dest.writeFloat(costPerTime);
        dest.writeFloat(costPerSec);
        dest.writeLong(dateCreated.getTime());
        dest.writeString(timeSince);
        dest.writeDouble(moneySaved);
    }
}
