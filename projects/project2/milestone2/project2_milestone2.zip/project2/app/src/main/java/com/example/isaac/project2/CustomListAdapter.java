package com.example.isaac.project2;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomListAdapter extends ArrayAdapter {

    //to reference the Activity
    private final Activity context;

    //to store the habit title
    private final ArrayList<Habit> habit;

//    //to store the indulged time
//    private final String lastIndulged;
//
//    //to store the money
//    private final String moneySaved;

    public CustomListAdapter(Activity context, ArrayList<Habit> curHabit){

        super(context,R.layout.listview_row , curHabit);

        this.context=context;
        this.habit = curHabit;
//        this.lastIndulged = String.valueOf(curHabit[0].getDateCreated());
//        this.moneySaved = moneyArrayParam;
    }

    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.listview_row, null,true);

        //this code gets references to objects in the listview_row.xml file
        TextView titleTextField = (TextView) rowView.findViewById(R.id.habitTitle);
        TextView moneyTextField = (TextView) rowView.findViewById(R.id.habitMoneySaved);
        TextView indulgedTextField = (TextView) rowView.findViewById(R.id.habitLastIndulged);

        //this code sets the values of the objects to values from the arrays
        titleTextField.setText(habit.get(position).getHabitTitle());
        moneyTextField.setText("$" + String.format("%.2f", habit.get(position).getMoneySaved()));
        indulgedTextField.setText(habit.get(position).getTimeSince());

        return rowView;

    };

}


