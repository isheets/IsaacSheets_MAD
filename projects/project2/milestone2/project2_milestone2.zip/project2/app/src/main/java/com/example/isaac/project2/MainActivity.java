package com.example.isaac.project2;

import android.app.Activity;
import android.content.DialogInterface;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    Habit testHabit = new Habit("test", 2, 2, 0, 0, new Date(), "2m 45s ago", 3.15);
    Habit testHabit2 = new Habit("test2", 2, 2, 1, 0, new Date(), "10m 8s ago", 5.10);

    //Habit[] habitArray = {testHabit, testHabit2};

    ArrayList<Habit> habitArray = new ArrayList<Habit>();

    ListView listView;

    SwipeRefreshLayout pullToRefresh;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //toolbar stuff
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        //adapt array to listview
        final CustomListAdapter list = new CustomListAdapter(this, habitArray);
        listView = (ListView) findViewById(R.id.listViewID);
        listView.setAdapter(list);
        habitArray.add(testHabit);
        habitArray.add(testHabit2);

        //handle FAB
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab1);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addHabit(view);
            }
        });

        //pull to refresh
        pullToRefresh = findViewById(R.id.swipe);

        pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshTableData();
                pullToRefresh.setRefreshing(false);
            }
        });

        //lonog press to delete
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view,
                                           final int position, long id) {
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setMessage("Are you sure you want to delete " + habitArray.get(position).getHabitTitle() + "?");
                alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        habitArray.remove(position);//where arg2 is position of item you click
                        refreshTableData();
                        dialog.dismiss();

                    }
                });
                alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                    }
                });

                alert.show();

                return false;
            }
        });

        //press to edit
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> list, View v, int pos, long id) {
                Intent intent = new Intent(MainActivity.this, AddHabit.class);
                intent.putExtra("habitToEdit", habitArray.get(pos));
                intent.putExtra("action", true);
                intent.putExtra("index", pos);
                startActivityForResult(intent, 1);
            }
        });


    }


    private void updateHabit() {
        for(int i = 0; i < habitArray.size(); i++) {
            String timeString;
            double moneySaved;

            Date curDate = new Date();
            long diffInMs = curDate.getTime() - habitArray.get(i).getDateCreated().getTime();
            long diffInSec = TimeUnit.MILLISECONDS.toSeconds(diffInMs);

            //format last indulged string
            int day = (int)TimeUnit.SECONDS.toDays(diffInSec);
            long hours = TimeUnit.SECONDS.toHours(diffInSec) - (day *24);
            long minute = TimeUnit.SECONDS.toMinutes(diffInSec) - (TimeUnit.SECONDS.toHours(diffInSec)* 60);
            long second = TimeUnit.SECONDS.toSeconds(diffInSec) - (TimeUnit.SECONDS.toMinutes(diffInSec) *60);

            if (day < 1) {
                if(hours < 1) {
                    if (minute < 1) {
                        timeString = second + "s ago";
                    }
                    else {
                        timeString = minute + "m " + second + "s ago";
                    }
                }
                else {
                    timeString = hours + "h " + minute + "m ago";
                }
            }
            else {
                timeString = day + "d " + hours + "h ago";
            }

            //calculate money saved
            moneySaved = diffInSec * habitArray.get(i).getCostPerSec();

            habitArray.get(i).setTimeSince(timeString);
            habitArray.get(i).setMoneySaved(moneySaved);
        }

    }

    private void addHabit(View view) {
        Intent intent = new Intent(this, AddHabit.class);
        intent.putExtra("action", false);
        //start intent
        startActivityForResult(intent, 1);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.i("result", "we're back and we got a result");
        // Check which request we're responding to
        if (requestCode == 1) {
            // Make sure the request was successful
            if (resultCode == 1)    {
                //and we have a new habit folks!
                //get the habit and add to list
                Habit newHabit = data.getParcelableExtra("newHabit");
                Log.i("result", newHabit.habitTitle);
                habitArray.add(newHabit);
                Log.i("result", String.valueOf(habitArray.size()));
                //update listview
                refreshTableData();
            }
            if(resultCode == 2) {
                //looks like we edited a habit folks!
                //let's update it
                Habit editHabit = data.getParcelableExtra("editedHabit");
                int index = data.getIntExtra("index", 0);
                habitArray.set(index, editHabit);
                //and update the listview
                refreshTableData();
            }
        }
    }

    public void refreshTableData() {
        updateHabit();
        ((BaseAdapter)listView.getAdapter()).notifyDataSetChanged();
    }


}
