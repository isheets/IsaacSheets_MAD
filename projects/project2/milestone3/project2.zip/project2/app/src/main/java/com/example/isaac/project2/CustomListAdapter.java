package com.example.isaac.project2;

import android.app.Activity;
import android.graphics.Color;
import android.support.constraint.ConstraintLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class CustomListAdapter extends ArrayAdapter {

    //to reference the Activity
    private final Activity context;

    //to store the habits
    private final ArrayList<Habit> habit;

    public CustomListAdapter(Activity context, ArrayList<Habit> curHabit){

        super(context,R.layout.listview_row , curHabit);

        this.context=context;
        this.habit = curHabit;
    }

    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.listview_row, null,true);

        //this code gets references to objects in the listview_row.xml file
        TextView titleTextField = (TextView) rowView.findViewById(R.id.habitTitle);
        TextView moneyTextField = (TextView) rowView.findViewById(R.id.habitMoneySaved);
        TextView indulgedTextField = (TextView) rowView.findViewById(R.id.habitLastIndulged);

        //this code sets the values of the objects to values from the arrays
        titleTextField.setText(habit.get(position).getHabitTitle());
        moneyTextField.setText("$" + String.format("%.2f", habit.get(position).getMoneySaved()));
        indulgedTextField.setText(habit.get(position).getTimeSince());

        Date curDate = new Date();
        long diffInMs = curDate.getTime() - habit.get(position).getDateCreated().getTime();
        long diffInSec = TimeUnit.MILLISECONDS.toSeconds(diffInMs);

        if(diffInSec < habit.get(position).getSecBetween()) {
            //red
            rowView.setBackgroundColor(context.getResources().getColor(R.color.lightRed));
        }
        else if (diffInSec < (habit.get(position).getSecBetween() * 2)) {
            //yellow
            rowView.setBackgroundColor(context.getResources().getColor(R.color.yellow));
        }
        else {
            rowView.setBackgroundColor(context.getResources().getColor(R.color.green));
        }

        return rowView;

    };


}


