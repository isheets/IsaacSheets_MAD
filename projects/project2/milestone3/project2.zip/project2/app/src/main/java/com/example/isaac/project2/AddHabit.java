package com.example.isaac.project2;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

public class AddHabit extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    //get instances of views
    EditText titleField;
    EditText freqField;
    EditText costField;
    Spinner spinner;
    Button indulgedButt;

    int timeInterval;

    boolean edit = false;

    //if we're editing, put habit to edit here
    Habit habitToEdit;
    int indexOfEdit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_habit);

        titleField = findViewById(R.id.titleField);
        freqField = findViewById(R.id.freqField);
        costField = findViewById(R.id.costField);
        spinner = findViewById(R.id.spinner);
        indulgedButt = findViewById(R.id.indulged);

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.freqOptions, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        Intent intent = getIntent();
        edit = intent.getExtras().getBoolean("action");


        //toolbar and button stuff
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        if(edit == false) {
            myToolbar.setTitle("add habit");
            indulgedButt.setVisibility(View.GONE);
        }

        else if(edit == true) {
            //indulgedButt.setVisibility(View.VISIBLE);
            myToolbar.setTitle("edit habit");
            habitToEdit = intent.getParcelableExtra("habitToEdit");
            indexOfEdit = intent.getIntExtra("index", 0);
            populateHabitToEdit();
        }

        //add listener to the button
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                Log.i("fuck", "why doesn't this work");
                indulgedHabit(view);
            }
        };

        indulgedButt.setOnClickListener(onclick);

        setSupportActionBar(myToolbar);

    }


    private void populateHabitToEdit() {
        titleField.setText(habitToEdit.getHabitTitle());
        freqField.setText(Integer.toString(habitToEdit.getNumTimes()));
        spinner.setSelection(habitToEdit.getTimeInterval());
        costField.setText(Float.toString(habitToEdit.getCostPerTime()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // inflate the menu
        getMenuInflater().inflate(R.menu.custom_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_done:
                if (edit == false) {
                    saveNewHabit();
                }
                else {
                    saveEditHabit();
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }

    private void saveNewHabit() {
        if(titleField.getText().toString().matches("") || freqField.getText().toString().matches("") || costField.getText().toString().matches("")) {
            Context context = getApplicationContext();
            CharSequence text = "Please fill in every field!";
            int duration = Toast.LENGTH_LONG;
            Toast toast = Toast.makeText(context, text, duration);
            View view = toast.getView();

//Gets the actual oval background of the Toast then sets the colour filter
            view.getBackground().setColorFilter(getResources().getColor(R.color.primaryDarkColor), PorterDuff.Mode.SRC_IN);

            toast.show();

        }
        else {
            //create habit object
            Habit newHabit = parseUserEntry();

            //put new habit in intent
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("newHabit", newHabit);

            //put intent in result
            setResult(1, intent);
            //and we're done!
            finish();
        }
    }

    private void saveEditHabit() {
        if (titleField.getText().toString() == "") {
            Context context = getApplicationContext();
            CharSequence text = "Hello toast!";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else {
            //update habit with any changes made by user
            habitToEdit = parseUserEntry();

            //put updated habit and index in intent
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("editedHabit", habitToEdit);
            intent.putExtra("index", indexOfEdit);

            //put intent in result
            setResult(2, intent);

            finish();
        }
    }

    private Habit parseUserEntry() {

        String title = titleField.getText().toString();


        int times = Integer.parseInt(freqField.getText().toString());

        float costPerTime = Float.parseFloat(costField.getText().toString());

        float secBetween;
        float costPerSec;

        if(timeInterval == 0) {
            secBetween = 3600/times;
            costPerSec = costPerTime/secBetween;
        }
        else if(timeInterval == 1) {
            secBetween = 86400/times;
            costPerSec = costPerTime/secBetween;
        }
        else if(timeInterval == 2) {
            secBetween = 604800/times;
            costPerSec = costPerTime/secBetween;
        }
        else if(timeInterval == 3) {
            secBetween = 2628000/times;
            costPerSec = costPerTime/secBetween;
        }
        else {
            costPerSec = 0;
            secBetween = 0;
        }
        if (edit == false) {
            //its a new habit so create a new object
            Habit userHabit = new Habit(title, times, timeInterval, costPerTime, costPerSec, secBetween, new Date(), "", 0.00);
            return userHabit;
        }
        else {
            //we're editing so just update the habit
            habitToEdit.setHabitTitle(title);
            habitToEdit.setCostPerSec(costPerSec);
            habitToEdit.setCostPerTime(costPerTime);
            habitToEdit.setNumTimes(times);
            habitToEdit.setTimeInterval(timeInterval);
            habitToEdit.setSecBetween(secBetween);
            return habitToEdit;
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        timeInterval = spinner.getSelectedItemPosition();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    public void indulgedHabit(View view) {
        Log.i("clicked", "function called!");
        AlertDialog.Builder alert = new AlertDialog.Builder(AddHabit.this);
        alert.setMessage("All that work down the drain. Shame! Shame!");
        alert.setPositiveButton("SORRY! Won't happen again.", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                habitToEdit.setDateCreated(new Date());
                dialog.dismiss();
                habitToEdit = parseUserEntry();
                saveEditHabit();
            }
        });
        alert.show();

    }

}
